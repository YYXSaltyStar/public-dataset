#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, csv, gzip, glob, math, os
from pathlib import Path
from typing import Dict, Any, List
from pymatgen.core.periodic_table import Element

# -----------------------------
# Radii
# -----------------------------
ATOMIC_RADII: Dict[str, float] = {
    'H': 0.31, 'B': 0.85, 'C': 0.76, 'N': 0.71, 'O': 0.66, 'F': 0.57,
    'Si': 1.11, 'P': 1.07, 'S': 1.05, 'Cl': 1.02,
    'As': 1.19, 'Se': 1.20, 'Br': 1.20, 'Te': 1.38, 'I': 1.39, 'At': 1.48,

    'Li': 1.28, 'Be': 0.96, 'Na': 1.66, 'Mg': 1.41, 'K': 2.03, 'Ca': 1.76, 'Rb': 2.20, 'Sr': 1.95, 'Cs': 2.44, 'Ba': 2.15,
    'Sc': 1.48, 'Ti': 1.36, 'V': 1.35,  'Cr': 1.27, 'Mn': 1.27, 'Fe': 1.26, 'Co': 1.25, 'Ni': 1.24, 'Cu': 1.28, 'Zn': 1.31,
    'Y': 1.62,  'Zr': 1.48, 'Nb': 1.37, 'Mo': 1.35, 'Ru': 1.26, 'Rh': 1.25, 'Pd': 1.28, 'Ag': 1.44, 'Cd': 1.48,
    'Hf': 1.50, 'Ta': 1.38, 'W': 1.37,  'Re': 1.28, 'Os': 1.26, 'Ir': 1.27, 'Pt': 1.30, 'Au': 1.34, 'Hg': 1.49,
    'Al': 1.25, 'Ga': 1.26, 'In': 1.44, 'Sn': 1.41, 'Tl': 1.48, 'Pb': 1.47, 'Bi': 1.51,
    'Ge': 1.22, 'Sb': 1.40,
    'La': 1.69, 'Ce': 1.65, 'Pr': 1.65, 'Nd': 1.64, 'Sm': 1.62, 'Eu': 1.85, 'Gd': 1.61,
    'Tb': 1.59, 'Dy': 1.59, 'Ho': 1.58, 'Er': 1.57, 'Tm': 1.56, 'Yb': 1.74, 'Lu': 1.56,

    'Tc': 1.28,
    'Pm': 1.63,
}

X_CHARGE = {"C": -4, "N": -3}
TERM_CHARGE = {"O": -2, "S": -2, "F": -1, "Cl": -1}

RADIO_FALLBACK = {"Tc","Pm","Po","Fr","Ra","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rn","At"}

def is_radioactive(sym: str) -> bool:
    try:
        return bool(Element(sym).is_radioactive)
    except Exception:
        return sym in RADIO_FALLBACK

def _r(sym: str) -> float:
    if sym not in ATOMIC_RADII:
        raise KeyError(f"Missing radius for element: {sym}")
    return ATOMIC_RADII[sym]

def _en(sym: str) -> float:
    x = Element(sym).X
    if x is None:
        raise ValueError(f"Missing electronegativity for {sym} in pymatgen")
    v = float(x)
    if not math.isfinite(v):
        raise ValueError(f"Non-finite electronegativity for {sym}: {v}")
    return v

def metal_ox_state_proxy(sym: str) -> int:
    g = Element(sym).group
    if g in (3,4,5,6):
        return g
    e = Element(sym)
    if e.common_oxidation_states:
        pos = [v for v in e.common_oxidation_states if v > 0]
        return max(pos) if pos else 0
    return 0

def parse_concat_symbols(tag: str) -> List[str]:
    metals = []
    i = 0
    while i < len(tag):
        if i+2 <= len(tag) and Element.is_valid_symbol(tag[i:i+2]):
            metals.append(tag[i:i+2]); i += 2
        else:
            metals.append(tag[i:i+1]); i += 1
    return metals

def delta_r_max(metals: List[str]) -> float:
    if len(metals) <= 1:
        return 0.0
    rs = [_r(m) for m in metals]
    mx = 0.0
    for i in range(len(rs)):
        for j in range(i+1, len(rs)):
            mx = max(mx, abs(rs[i]-rs[j]) / ((rs[i]+rs[j])/2.0))
    return mx

def list_files(in_glob: str) -> List[str]:
    files = sorted(glob.glob(in_glob))
    if not files:
        raise FileNotFoundError(f'No files matched --in_glob="{in_glob}". CWD={os.getcwd()}')
    return files

OUT_FIELDS = [
    "global_index","family","system_id","outer","inner","metal_tuple","X","term","site","poscar_relpath",
    "chi_M_avg","r_ratio","delta_r","deltaQ"
]

def compute_features(row: Dict[str,str]) -> Dict[str,Any]:
    # expected input columns in catalog
    req = ["global_index","family","system_id","outer","inner","metal_tuple","X","term","site","poscar_relpath"]
    miss = [k for k in req if k not in row]
    if miss:
        raise KeyError(f"Catalog missing columns={miss}. got={list(row.keys())}")

    family = row["family"]
    sid = row["system_id"]
    x = row["X"]
    term = row["term"]

    if family == "HE":
        metals = parse_concat_symbols(row["metal_tuple"])
        chi = sum(_en(m) for m in metals) / len(metals)
        rM  = sum(_r(m) for m in metals) / len(metals)
        dr  = delta_r_max(metals)
        qM  = sum(metal_ox_state_proxy(m) for m in metals) / len(metals)
        deltaQ = 4*qM + X_CHARGE[x]*3 + TERM_CHARGE.get(term,0)*2

        # keep outer/inner empty for HE
        return dict(
            global_index=int(row["global_index"]),
            family=family,
            system_id=sid,
            outer="",
            inner="",
            metal_tuple=row["metal_tuple"],
            X=x,
            term=term,
            site=row["site"],
            poscar_relpath=row["poscar_relpath"],
            chi_M_avg=float(chi),
            r_ratio=float(rM/_r(x)),
            delta_r=float(dr),
            deltaQ=float(deltaQ),
        )

    # BASE
    outer = row["outer"]
    inner = row["inner"] or outer

    if sid == "S1": no, ni, xn = 3, 0, 2
    elif sid == "S2": no, ni, xn = 2, 1, 2
    elif sid == "S3": no, ni, xn = 4, 0, 3
    elif sid == "S4": no, ni, xn = 2, 2, 3
    else: raise ValueError(f"Unknown system_id={sid}")

    chi = (_en(outer)*no + _en(inner)*ni)/(no+ni)
    rM  = (_r(outer)*no + _r(inner)*ni)/(no+ni)
    dr  = 0.0 if inner == outer else abs(_r(outer)-_r(inner))/((_r(outer)+_r(inner))/2.0)
    deltaQ = metal_ox_state_proxy(outer)*no + metal_ox_state_proxy(inner)*ni + X_CHARGE[x]*xn + TERM_CHARGE.get(term,0)*2

    return dict(
        global_index=int(row["global_index"]),
        family=family,
        system_id=sid,
        outer=outer,
        inner=("" if inner == outer else inner),
        metal_tuple=row["metal_tuple"],
        X=x,
        term=term,
        site=row["site"],
        poscar_relpath=row["poscar_relpath"],
        chi_M_avg=float(chi),
        r_ratio=float(rM/_r(x)),
        delta_r=float(dr),
        deltaQ=float(deltaQ),
    )

def extract_one(catalog_path: Path, out_path: Path, exclude_radioactive: bool):
    with gzip.open(catalog_path, "rt") as fin, gzip.open(out_path, "wt", newline="") as fout:
        rd = csv.DictReader(fin)
        wr = csv.DictWriter(fout, fieldnames=OUT_FIELDS)
        wr.writeheader()

        n_in = 0
        n_out = 0
        for row in rd:
            n_in += 1
            feat = compute_features(row)

            if exclude_radioactive:
                metals = []
                if feat["family"] == "HE":
                    metals = parse_concat_symbols(feat["metal_tuple"])
                else:
                    if feat["outer"]: metals.append(feat["outer"])
                    if feat["inner"]: metals.append(feat["inner"])
                if any(is_radioactive(m) for m in metals):
                    continue

            wr.writerow({k: feat.get(k, "") for k in OUT_FIELDS})
            n_out += 1

    print(f"[OK] {catalog_path.name} -> {out_path.name}  rows_in={n_in} rows_out={n_out}")

def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument("--in_glob", default="catalog_shard*.csv.gz")
    ap.add_argument("--out_dir", default="features")
    ap.add_argument("--exclude_radioactive", action="store_true")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = list_files(args.in_glob)
    for fp in files:
        p = Path(fp)
        # catalog_shardXX.csv.gz -> features_shardXX.csv.gz
        shard = p.stem.replace("catalog_shard", "").replace(".csv", "")
        out = out_dir / f"features_shard{shard}.csv.gz"
        extract_one(p, out, args.exclude_radioactive)

if __name__ == "__main__":
    main()

