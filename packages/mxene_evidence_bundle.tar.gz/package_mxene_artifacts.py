#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse
import hashlib
import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Tuple


def sha256_file(p: Path, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def write_manifest_and_checksums(files: List[Path], out_dir: Path) -> Tuple[Path, Path]:
    manifest = out_dir / "manifest.txt"
    sums = out_dir / "sha256sums.txt"

    lines = []
    sum_lines = []

    for p in sorted(files, key=lambda x: str(x)):
        if not p.exists():
            continue
        size = p.stat().st_size
        rel = p.as_posix()
        lines.append(f"{size}\t{rel}")
        if p.is_file():
            sum_lines.append(f"{sha256_file(p)}  {rel}")

    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    sums.write_text("\n".join(sum_lines) + "\n", encoding="utf-8")
    return manifest, sums


def have_pigz() -> bool:
    return shutil.which("pigz") is not None


def run_tar_pigz(out_tgz: Path, members: List[Path], threads: int = 64) -> None:
    """
    Create tar.gz using pigz (parallel gzip).
    """
    out_tgz.parent.mkdir(parents=True, exist_ok=True)

    # tar expects relative paths to keep archive clean
    rel_members = [str(m) for m in members if m.exists()]
    if not rel_members:
        raise RuntimeError("No valid members to archive.")

    if have_pigz():
        # tar -cf - <members> | pigz -p N > out.tgz
        tar_cmd = ["tar", "-cf", "-", *rel_members]
        pigz_cmd = ["pigz", "-p", str(threads)]
        with out_tgz.open("wb") as out_f:
            p1 = subprocess.Popen(tar_cmd, stdout=subprocess.PIPE)
            p2 = subprocess.Popen(pigz_cmd, stdin=p1.stdout, stdout=out_f)
            assert p1.stdout is not None
            p1.stdout.close()
            r2 = p2.wait()
            r1 = p1.wait()
        if r1 != 0 or r2 != 0:
            raise RuntimeError(f"tar/pigz failed: tar={r1}, pigz={r2}")
    else:
        # fallback: tar -czf
        tar_cmd = ["tar", "-czf", str(out_tgz), *rel_members]
        r = subprocess.run(tar_cmd).returncode
        if r != 0:
            raise RuntimeError(f"tar -czf failed with code {r}")


def collect_glob(glob_patterns: List[str]) -> List[Path]:
    out: List[Path] = []
    for pat in glob_patterns:
        out.extend([Path(p) for p in sorted(Path(".").glob(pat))])
    # de-dup
    uniq = []
    seen = set()
    for p in out:
        s = p.as_posix()
        if s not in seen and p.exists():
            uniq.append(p)
            seen.add(s)
    return uniq


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", type=int, default=64, help="pigz threads (default: 64)")
    ap.add_argument("--with_poscars", action="store_true", help="include final_4896_poscars/ (if exists)")
    ap.add_argument("--with_virtual_catalog", action="store_true", help="include catalog_shard*.csv.gz (virtual catalog)")
    ap.add_argument("--out_dir", default="packages", help="where to write archives (default: packages)")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ---- Evidence bundle: scripts + params + counts + kept list + thresholds
    evidence_patterns = [
        "best_params.json",
        "recommended_thresholds.json",
        "mxene_screen_all_counts_and_thresholds.json",
        "mxene_screen_counts*.json",
        "*_counts_shard*.json",
        "tight_from_kept.json",
        "mxene_screen_all_kept_all.csv.gz",
        "mxene_screen_kept_all.csv.gz",
        "*.py",
    ]
    evidence_members = collect_glob(evidence_patterns)

    # also include packaging outputs later (manifest/checksums) inside evidence bundle
    # but we create those at the end

    evidence_tgz = out_dir / "mxene_evidence_bundle.tar.gz"
    run_tar_pigz(evidence_tgz, evidence_members, threads=args.threads)

    # ---- Final 4896 POSCARs (optional)
    poscar_tgz = None
    if args.with_poscars and Path("final_4896_poscars").exists():
        poscar_tgz = out_dir / "final_4896_poscars.tar.gz"
        run_tar_pigz(poscar_tgz, [Path("final_4896_poscars")], threads=args.threads)

    # ---- Virtual catalog (optional)
    catalog_tgz = None
    if args.with_virtual_catalog:
        catalogs = collect_glob(["catalog_shard*.csv.gz"])
        if catalogs:
            catalog_tgz = out_dir / "mxene_virtual_catalog.tar.gz"
            run_tar_pigz(catalog_tgz, catalogs, threads=args.threads)

    # ---- Manifest + checksums for the produced archives
    produced = [evidence_tgz]
    if poscar_tgz:
        produced.append(poscar_tgz)
    if catalog_tgz:
        produced.append(catalog_tgz)

    manifest, sums = write_manifest_and_checksums(produced, out_dir)

    # Include manifest + sums as well (handy for reviewers)
    print("[OK] produced:")
    for p in produced:
        print("  -", p.resolve())
    print("[OK] manifest:", manifest.resolve())
    print("[OK] sha256sums:", sums.resolve())
    if have_pigz():
        print(f"[INFO] pigz enabled, threads={args.threads}")
    else:
        print("[WARN] pigz not found; used tar -czf fallback")


if __name__ == "__main__":
    main()

