#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, csv, gzip, json, glob, math
from pathlib import Path
from typing import Dict, Any, List
from collections import Counter
from pymatgen.core.periodic_table import Element

ATOMIC_RADII: Dict[str,float] = {
    'H':0.31,'B':0.85,'C':0.76,'N':0.71,'O':0.66,'F':0.57,'Si':1.11,'P':1.07,'S':1.05,'Cl':1.02,'As':1.19,'Se':1.20,'Br':1.20,'Te':1.38,'I':1.39,'At':1.48,
    'Li':1.28,'Be':0.96,'Na':1.66,'Mg':1.41,'K':2.03,'Ca':1.76,'Rb':2.20,'Sr':1.95,'Cs':2.44,'Ba':2.15,
    'Sc':1.48,'Ti':1.36,'V':1.35,'Cr':1.27,'Mn':1.27,'Fe':1.26,'Co':1.25,'Ni':1.24,'Cu':1.28,'Zn':1.31,
    'Y':1.62,'Zr':1.48,'Nb':1.37,'Mo':1.35,'Ru':1.26,'Rh':1.25,'Pd':1.28,'Ag':1.44,'Cd':1.48,
    'Hf':1.50,'Ta':1.38,'W':1.37,'Re':1.28,'Os':1.26,'Ir':1.27,'Pt':1.30,'Au':1.34,'Hg':1.49,
    'Al':1.25,'Ga':1.26,'In':1.44,'Sn':1.41,'Tl':1.48,'Pb':1.47,'Bi':1.51,'Ge':1.22,'Sb':1.40,
    'La':1.69,'Ce':1.65,'Pr':1.65,'Nd':1.64,'Sm':1.62,'Eu':1.85,'Gd':1.61,'Tb':1.59,'Dy':1.59,'Ho':1.58,'Er':1.57,'Tm':1.56,'Yb':1.74,'Lu':1.56,
    'Tc':1.28,'Pm':1.63,
}

X_CHARGE = {"C": -4, "N": -3}
TERM_CHARGE = {"O": -2, "S": -2, "F": -1, "Cl": -1}

RADIO_FALLBACK = {"Tc","Pm","Po","Fr","Ra","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rn","At"}

def is_radioactive(sym: str) -> bool:
    try:
        return bool(Element(sym).is_radioactive)
    except Exception:
        return sym in RADIO_FALLBACK

def _en(sym: str) -> float:
    x = Element(sym).X
    return float(x) if x is not None else float("nan")

def _r(sym: str) -> float:
    return ATOMIC_RADII[sym]

def metal_ox_state_proxy(sym: str) -> int:
    g = Element(sym).group
    if g in (3,4,5,6):
        return g
    e = Element(sym)
    if e.common_oxidation_states:
        pos = [v for v in e.common_oxidation_states if v > 0]
        return max(pos) if pos else 0
    return 0

def parse_concat_symbols(tag: str) -> List[str]:
    metals = []
    i = 0
    while i < len(tag):
        if i+2 <= len(tag) and Element.is_valid_symbol(tag[i:i+2]):
            metals.append(tag[i:i+2]); i += 2
        else:
            metals.append(tag[i:i+1]); i += 1
    return metals

def delta_r_max(metals: List[str]) -> float:
    if len(metals) <= 1:
        return 0.0
    rs = [_r(m) for m in metals]
    mx = 0.0
    for i in range(len(rs)):
        for j in range(i+1,len(rs)):
            mx = max(mx, abs(rs[i]-rs[j]) / ((rs[i]+rs[j])/2.0))
    return mx

def compute_features(row: Dict[str,str]) -> Dict[str,Any]:
    family = row.get("family","BASE")
    sid = row["system_id"]
    x = row["X"]
    term = row["term"]
    site = row["site"]

    if family == "HE":
        metals = parse_concat_symbols(row["metal_tuple"])
        # equimolar averages
        chi = sum(_en(m) for m in metals)/len(metals)
        rM = sum(_r(m) for m in metals)/len(metals)
        dr = delta_r_max(metals)
        # M4X3: 4 metals, 3 X
        qM = sum(metal_ox_state_proxy(m) for m in metals)/len(metals)
        deltaQ = 4*qM + X_CHARGE[x]*3 + TERM_CHARGE.get(term,0)*2
        groups = [Element(m).group for m in metals]
        return dict(
            global_index=row["global_index"], family=family, system_id=sid,
            metals=",".join(metals), outer="", inner="",
            X=x, term=term, site=site,
            chi_M_avg=chi, r_ratio=rM/_r(x), delta_r=dr, deltaQ=deltaQ,
            k_metals=len(metals), ln_k=math.log(len(metals)),
            groups=",".join(str(g) for g in groups),
            poscar_relpath=row["poscar_relpath"]
        )

    # BASE
    outer = row["outer"]
    inner = row.get("inner","") or outer

    # system weights
    if sid == "S1":
        no,ni,xn = 3,0,2
    elif sid == "S2":
        no,ni,xn = 2,1,2
    elif sid == "S3":
        no,ni,xn = 4,0,3
    elif sid == "S4":
        no,ni,xn = 2,2,3
    else:
        raise ValueError(f"unknown system_id={sid}")

    chi = (_en(outer)*no + _en(inner)*ni)/(no+ni)
    rM  = (_r(outer)*no + _r(inner)*ni)/(no+ni)
    dr = 0.0 if inner==outer else abs(_r(outer)-_r(inner))/((_r(outer)+_r(inner))/2.0)
    deltaQ = metal_ox_state_proxy(outer)*no + metal_ox_state_proxy(inner)*ni + X_CHARGE[x]*xn + TERM_CHARGE.get(term,0)*2
    groups = [Element(outer).group] + ([] if inner==outer else [Element(inner).group])

    return dict(
        global_index=row["global_index"], family=family, system_id=sid,
        metals=outer + ("" if inner==outer else f",{inner}"), outer=outer, inner=("" if inner==outer else inner),
        X=x, term=term, site=site,
        chi_M_avg=chi, r_ratio=rM/_r(x), delta_r=dr, deltaQ=deltaQ,
        k_metals=(1 if inner==outer else 2), ln_k=math.log(1 if inner==outer else 2),
        groups=",".join(str(g) for g in groups),
        poscar_relpath=row["poscar_relpath"]
    )

def quantile(vals_sorted: List[float], q: float) -> float:
    if not vals_sorted:
        return float("nan")
    pos = q*(len(vals_sorted)-1)
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return vals_sorted[lo]
    return vals_sorted[lo] + (vals_sorted[hi]-vals_sorted[lo])*(pos-lo)

def derive_thresholds(in_glob: str,
                      allowed_terms: List[str],
                      dr_max: float,
                      charge_tol: float,
                      exclude_radioactive: bool) -> Dict[str,Any]:
    chi_vals, rC, rN = [], [], []
    g_counter = Counter()
    n0 = 0
    n_surv = 0

    for fp in sorted(glob.glob(in_glob)):
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for row in rd:
                n0 += 1
                feat = compute_features(row)

                # optional radioactive removal
                if exclude_radioactive and feat["metals"]:
                    for m in feat["metals"].split(","):
                        if m and is_radioactive(m):
                            break
                    else:
                        pass
                    # if break triggered:
                    if any(m and is_radioactive(m) for m in feat["metals"].split(",")):
                        continue

                # Step2-5 only (用于反推 Step1)
                if feat["term"] not in allowed_terms:
                    continue
                if feat["delta_r"] > dr_max:
                    continue
                if abs(feat["deltaQ"]) > charge_tol:
                    continue

                n_surv += 1
                chi_vals.append(feat["chi_M_avg"])
                if feat["X"] == "C":
                    rC.append(feat["r_ratio"])
                else:
                    rN.append(feat["r_ratio"])
                for g in feat["groups"].split(","):
                    if g.strip():
                        g_counter[int(g)] += 1

    chi_vals.sort(); rC.sort(); rN.sort()

    chi_lo = quantile(chi_vals, 0.01)
    chi_hi = quantile(chi_vals, 0.99)
    rC_lo, rC_hi = quantile(rC, 0.01), quantile(rC, 0.99)
    rN_lo, rN_hi = quantile(rN, 0.01), quantile(rN, 0.99)

    # group whitelist: top groups covering 99%
    total = sum(g_counter.values())
    keep = []
    cum = 0
    for g, c in g_counter.most_common():
        keep.append(g); cum += c
        if total > 0 and cum/total >= 0.99:
            break

    return dict(
        n0=n0, n_survive_2_5=n_surv,
        recommended=dict(
            step1=dict(group_whitelist=sorted(keep), chi_range=[chi_lo, chi_hi]),
            step2=dict(allowed_terms=allowed_terms),
            step3=dict(delta_r_max=dr_max),
            step4=dict(r_ratio_bounds={"C":[rC_lo,rC_hi], "N":[rN_lo,rN_hi]}),
            step5=dict(charge_tol=charge_tol),
            exclude_radioactive=exclude_radioactive
        )
    )

def screen(in_glob: str, thr: Dict[str,Any], out_prefix: str, write_kept: bool):
    s1,s2,s3,s4,s5 = thr["step1"],thr["step2"],thr["step3"],thr["step4"],thr["step5"]
    gset = set(s1["group_whitelist"])
    chi_lo, chi_hi = s1["chi_range"]
    terms = set(s2["allowed_terms"])
    dr_max = float(s3["delta_r_max"])
    rC_lo,rC_hi = s4["r_ratio_bounds"]["C"]
    rN_lo,rN_hi = s4["r_ratio_bounds"]["N"]
    qtol = float(s5["charge_tol"])
    excl_rad = bool(thr.get("exclude_radioactive", True))

    N0=N1=N2=N3=N4=N5=0

    kept_path = Path(f"{out_prefix}_kept_all.csv.gz")
    kept_f = gzip.open(kept_path, "wt", newline="") if write_kept else None
    kept_w = None
    if kept_f:
        kept_w = csv.DictWriter(kept_f, fieldnames=[
            "global_index","family","system_id","metals","outer","inner","X","term","site",
            "chi_M_avg","r_ratio","delta_r","deltaQ","k_metals","ln_k","groups","poscar_relpath"
        ])
        kept_w.writeheader()

    for fp in sorted(glob.glob(in_glob)):
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for row in rd:
                N0 += 1
                feat = compute_features(row)

                if excl_rad and feat["metals"]:
                    if any(m and is_radioactive(m) for m in feat["metals"].split(",")):
                        continue

                # Step1 (data-driven thresholds)
                groups = [int(g) for g in feat["groups"].split(",") if g.strip()]
                if any(g not in gset for g in groups):
                    continue
                if not (chi_lo <= feat["chi_M_avg"] <= chi_hi):
                    continue
                N1 += 1

                # Step2
                if feat["term"] not in terms:
                    continue
                N2 += 1

                # Step3
                if feat["delta_r"] > dr_max:
                    continue
                N3 += 1

                # Step4
                rr = feat["r_ratio"]
                if feat["X"] == "C":
                    if not (rC_lo <= rr <= rC_hi):
                        continue
                else:
                    if not (rN_lo <= rr <= rN_hi):
                        continue
                N4 += 1

                # Step5
                if abs(feat["deltaQ"]) > qtol:
                    continue
                N5 += 1

                if kept_w:
                    kept_w.writerow(feat)

    if kept_f:
        kept_f.close()

    out = Path(f"{out_prefix}_counts_and_thresholds.json")
    out.write_text(json.dumps(dict(
        thresholds=thr,
        counts=dict(N0_total=N0, N1_after_step1=N1, N2_after_step2=N2, N3_after_step3=N3, N4_after_step4=N4, N5_after_step5=N5)
    ), indent=2), encoding="utf-8")

    print(json.dumps(dict(N0_total=N0, N1_after_step1=N1, N2_after_step2=N2, N3_after_step3=N3, N4_after_step4=N4, N5_after_step5=N5), indent=2))
    print(f"[OK] wrote {out}")
    if write_kept:
        print(f"[OK] kept list: {kept_path}")

def parse_args():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    p_d = sub.add_parser("derive")
    p_d.add_argument("--in_glob", required=True, help='e.g. "mxene_all/catalog_shard*.csv.gz"')
    p_d.add_argument("--out_json", default="recommended_thresholds.json")
    p_d.add_argument("--allowed_terms", nargs="+", default=["O","S","F","Cl"])
    p_d.add_argument("--delta_r_max", type=float, default=0.15)
    p_d.add_argument("--charge_tol", type=float, default=2.0)
    p_d.add_argument("--exclude_radioactive", action="store_true")

    p_s = sub.add_parser("screen")
    p_s.add_argument("--in_glob", required=True)
    p_s.add_argument("--thr_json", required=True)
    p_s.add_argument("--out_prefix", default="mxene_screen")
    p_s.add_argument("--write_kept", action="store_true")

    return p.parse_args()

def main():
    args = parse_args()
    if args.cmd == "derive":
        res = derive_thresholds(args.in_glob, args.allowed_terms, args.delta_r_max, args.charge_tol, args.exclude_radioactive)
        Path(args.out_json).write_text(json.dumps(res, indent=2), encoding="utf-8")
        print(f"[OK] wrote {args.out_json}")
        print(json.dumps(res["recommended"], indent=2))
    else:
        thr = json.loads(Path(args.thr_json).read_text(encoding="utf-8"))["recommended"]
        screen(args.in_glob, thr, args.out_prefix, args.write_kept)

if __name__ == "__main__":
    main()

