#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, csv, gzip, json, glob, os
from pathlib import Path
from typing import Dict, Any, List, Tuple, Set
from pymatgen.core.periodic_table import Element

# -----------------------------
# params (you can edit)
# -----------------------------
ALLOWED_TERMS = {"O","S","F","Cl"}  # step2
DELTA_R_MAX   = 0.15               # step3
CHARGE_TOL    = 2.0                # step5

# Step1: use group whitelist (data-driven or manual)
# If empty, script will NOT filter by step1 (so you can later derive).
GROUP_WHITELIST: Set[int] = set()  # e.g. {3,4,5,6}
CHI_RANGE: Tuple[float,float] | Tuple[None,None] = (None, None)  # e.g. (1.0, 2.1)

# Step4 bounds (if None, not applied)
R_RATIO_BOUNDS = {"C": (None,None), "N": (None,None)}

def list_files(in_glob: str) -> List[str]:
    files = sorted(glob.glob(in_glob))
    if not files:
        raise FileNotFoundError(f'No files matched --in_glob="{in_glob}". CWD={os.getcwd()}')
    return files

def passes_step1(r: Dict[str,str]) -> bool:
    if not GROUP_WHITELIST and (CHI_RANGE[0] is None or CHI_RANGE[1] is None):
        return True
    # group info not stored -> infer from metals
    metals = []
    if r["family"] == "HE":
        # metal_tuple is concatenated, split by Element symbols (simple parse)
        tag = r["metal_tuple"]
        i = 0
        while i < len(tag):
            if i+2 <= len(tag) and Element.is_valid_symbol(tag[i:i+2]):
                metals.append(tag[i:i+2]); i += 2
            else:
                metals.append(tag[i:i+1]); i += 1
    else:
        if r["outer"]: metals.append(r["outer"])
        if r["inner"]: metals.append(r["inner"])

    groups = [Element(m).group for m in metals]
    if GROUP_WHITELIST and any(g not in GROUP_WHITELIST for g in groups):
        return False

    lo, hi = CHI_RANGE
    if lo is not None and hi is not None:
        chi = float(r["chi_M_avg"])
        if not (lo <= chi <= hi):
            return False
    return True

def passes_step2(r: Dict[str,str]) -> bool:
    return r["term"] in ALLOWED_TERMS

def passes_step3(r: Dict[str,str]) -> bool:
    return float(r["delta_r"]) <= DELTA_R_MAX

def passes_step4(r: Dict[str,str]) -> bool:
    x = r["X"]
    lo, hi = R_RATIO_BOUNDS.get(x, (None,None))
    if lo is None or hi is None:
        return True
    rr = float(r["r_ratio"])
    return lo <= rr <= hi

def passes_step5(r: Dict[str,str]) -> bool:
    return abs(float(r["deltaQ"])) <= CHARGE_TOL

OUT_FIELDS = [
    "global_index","family","system_id","outer","inner","metal_tuple","X","term","site","poscar_relpath",
    "chi_M_avg","r_ratio","delta_r","deltaQ"
]

def screen_all(in_glob: str, out_prefix: str, write_kept: bool):
    files = list_files(in_glob)

    N0=N1=N2=N3=N4=N5=0
    kept_path = Path(f"{out_prefix}_kept_all.csv.gz")
    kept_f = gzip.open(kept_path, "wt", newline="") if write_kept else None
    kept_w = None
    if kept_f:
        kept_w = csv.DictWriter(kept_f, fieldnames=OUT_FIELDS)
        kept_w.writeheader()

    for fp in files:
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for r in rd:
                N0 += 1
                if not passes_step1(r): 
                    continue
                N1 += 1
                if not passes_step2(r):
                    continue
                N2 += 1
                if not passes_step3(r):
                    continue
                N3 += 1
                if not passes_step4(r):
                    continue
                N4 += 1
                if not passes_step5(r):
                    continue
                N5 += 1
                if kept_w:
                    kept_w.writerow({k: r.get(k,"") for k in OUT_FIELDS})

    if kept_f:
        kept_f.close()

    counts = {
        "N0_total": N0,
        "N1_after_step1": N1,
        "N2_after_step2": N2,
        "N3_after_step3": N3,
        "N4_after_step4": N4,
        "N5_after_step5": N5,
        "params": {
            "step1": {"group_whitelist": sorted(list(GROUP_WHITELIST)), "chi_range": list(CHI_RANGE)},
            "step2": {"allowed_terms": sorted(list(ALLOWED_TERMS))},
            "step3": {"delta_r_max": DELTA_R_MAX},
            "step4": {"r_ratio_bounds": {k:list(v) for k,v in R_RATIO_BOUNDS.items()}},
            "step5": {"charge_tol": CHARGE_TOL},
        }
    }
    Path(f"{out_prefix}_counts.json").write_text(json.dumps(counts, indent=2), encoding="utf-8")
    print(json.dumps(counts, indent=2))
    if write_kept:
        print(f"[OK] kept list: {kept_path}")

def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument("--in_glob", default="features/features_shard*.csv.gz")
    ap.add_argument("--out_prefix", default="mxene_screen")
    ap.add_argument("--write_kept", action="store_true")
    args = ap.parse_args()
    screen_all(args.in_glob, args.out_prefix, args.write_kept)

if __name__ == "__main__":
    main()

