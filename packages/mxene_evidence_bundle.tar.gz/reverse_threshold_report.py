#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, csv, gzip, glob, json, math, os
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Set
from collections import Counter
from pymatgen.core.periodic_table import Element

# -----------------------------
# Radii
# -----------------------------
ATOMIC_RADII: Dict[str, float] = {
    'H': 0.31, 'B': 0.85, 'C': 0.76, 'N': 0.71, 'O': 0.66, 'F': 0.57,
    'Si': 1.11, 'P': 1.07, 'S': 1.05, 'Cl': 1.02,
    'As': 1.19, 'Se': 1.20, 'Br': 1.20, 'Te': 1.38, 'I': 1.39, 'At': 1.48,

    'Li': 1.28, 'Be': 0.96, 'Na': 1.66, 'Mg': 1.41, 'K': 2.03, 'Ca': 1.76, 'Rb': 2.20, 'Sr': 1.95, 'Cs': 2.44, 'Ba': 2.15,
    'Sc': 1.48, 'Ti': 1.36, 'V': 1.35,  'Cr': 1.27, 'Mn': 1.27, 'Fe': 1.26, 'Co': 1.25, 'Ni': 1.24, 'Cu': 1.28, 'Zn': 1.31,
    'Y': 1.62,  'Zr': 1.48, 'Nb': 1.37, 'Mo': 1.35, 'Ru': 1.26, 'Rh': 1.25, 'Pd': 1.28, 'Ag': 1.44, 'Cd': 1.48,
    'Hf': 1.50, 'Ta': 1.38, 'W': 1.37,  'Re': 1.28, 'Os': 1.26, 'Ir': 1.27, 'Pt': 1.30, 'Au': 1.34, 'Hg': 1.49,
    'Al': 1.25, 'Ga': 1.26, 'In': 1.44, 'Sn': 1.41, 'Tl': 1.48, 'Pb': 1.47, 'Bi': 1.51,
    'Ge': 1.22, 'Sb': 1.40,
    'La': 1.69, 'Ce': 1.65, 'Pr': 1.65, 'Nd': 1.64, 'Sm': 1.62, 'Eu': 1.85, 'Gd': 1.61,
    'Tb': 1.59, 'Dy': 1.59, 'Ho': 1.58, 'Er': 1.57, 'Tm': 1.56, 'Yb': 1.74, 'Lu': 1.56,

    # optional
    'Tc': 1.28,
    'Pm': 1.63,
}

X_CHARGE = {"C": -4, "N": -3}
TERM_CHARGE = {"O": -2, "S": -2, "F": -1, "Cl": -1}

RADIO_FALLBACK = {"Tc","Pm","Po","Fr","Ra","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rn","At"}

def is_radioactive(sym: str) -> bool:
    try:
        return bool(Element(sym).is_radioactive)
    except Exception:
        return sym in RADIO_FALLBACK

def _r(sym: str) -> float:
    if sym not in ATOMIC_RADII:
        raise KeyError(f"Missing radius for element: {sym}")
    return ATOMIC_RADII[sym]

def _en(sym: str) -> float:
    x = Element(sym).X
    if x is None:
        raise ValueError(f"Missing electronegativity for {sym} in pymatgen")
    v = float(x)
    if not math.isfinite(v):
        raise ValueError(f"Non-finite electronegativity for {sym}: {v}")
    return v

def metal_ox_state_proxy(sym: str) -> int:
    g = Element(sym).group
    if g in (3,4,5,6):
        return g
    e = Element(sym)
    if e.common_oxidation_states:
        pos = [v for v in e.common_oxidation_states if v > 0]
        return max(pos) if pos else 0
    return 0

def parse_concat_symbols(tag: str) -> List[str]:
    metals = []
    i = 0
    while i < len(tag):
        if i+2 <= len(tag) and Element.is_valid_symbol(tag[i:i+2]):
            metals.append(tag[i:i+2]); i += 2
        else:
            metals.append(tag[i:i+1]); i += 1
    return metals

def delta_r_max(metals: List[str]) -> float:
    if len(metals) <= 1:
        return 0.0
    rs = [_r(m) for m in metals]
    mx = 0.0
    for i in range(len(rs)):
        for j in range(i+1, len(rs)):
            mx = max(mx, abs(rs[i]-rs[j]) / ((rs[i]+rs[j])/2.0))
    return mx

def list_files(in_glob: str) -> List[str]:
    files = sorted(glob.glob(in_glob))
    if not files:
        raise FileNotFoundError(
            f'No files matched --in_glob="{in_glob}". CWD={os.getcwd()}\n'
            f"Tip: if you are inside mxene_all, use --in_glob 'catalog_shard*.csv.gz'.\n"
            f"Tip: if outside, use --in_glob 'mxene_all/catalog_shard*.csv.gz'."
        )
    return files

def sanitize_json(obj: Any) -> Any:
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: sanitize_json(v) for k,v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_json(v) for v in obj]
    return obj

def load_thresholds(path: str) -> Dict[str, Any]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if "recommended" in raw:
        thr = raw["recommended"]
    elif "thresholds" in raw:
        thr = raw["thresholds"]
    else:
        thr = raw
    return sanitize_json(thr)

# --------- compute features from catalog row ---------
def compute_features_from_catalog(row: Dict[str, str]) -> Dict[str, Any]:
    req = ["global_index","family","system_id","outer","inner","metal_tuple","X","term","site","poscar_relpath"]
    miss = [k for k in req if k not in row]
    if miss:
        raise KeyError(f"Missing columns in catalog: {miss}. got={list(row.keys())}")

    family = row["family"]
    sid = row["system_id"]
    x = row["X"]
    term = row["term"]

    if family == "HE":
        metals = parse_concat_symbols(row["metal_tuple"])
        chi = sum(_en(m) for m in metals) / len(metals)
        rM = sum(_r(m) for m in metals) / len(metals)
        dr = delta_r_max(metals)
        qM = sum(metal_ox_state_proxy(m) for m in metals) / len(metals)
        deltaQ = 4*qM + X_CHARGE[x]*3 + TERM_CHARGE.get(term,0)*2
        groups = [Element(m).group for m in metals]
        return dict(family=family, system_id=sid, X=x, term=term,
                    metals=metals, groups=groups,
                    chi_M_avg=float(chi), r_ratio=float(rM/_r(x)),
                    delta_r=float(dr), deltaQ=float(deltaQ))

    outer = row["outer"]
    inner = row["inner"] or outer

    if sid == "S1": no, ni, xn = 3, 0, 2
    elif sid == "S2": no, ni, xn = 2, 1, 2
    elif sid == "S3": no, ni, xn = 4, 0, 3
    elif sid == "S4": no, ni, xn = 2, 2, 3
    else: raise ValueError(f"Unknown system_id={sid}")

    chi = (_en(outer)*no + _en(inner)*ni) / (no+ni)
    rM  = (_r(outer)*no  + _r(inner)*ni) / (no+ni)
    dr = 0.0 if inner == outer else abs(_r(outer)-_r(inner))/((_r(outer)+_r(inner))/2.0)
    deltaQ = metal_ox_state_proxy(outer)*no + metal_ox_state_proxy(inner)*ni + X_CHARGE[x]*xn + TERM_CHARGE.get(term,0)*2
    groups = [Element(outer).group] + ([] if inner == outer else [Element(inner).group])
    metals = [outer] + ([] if inner == outer else [inner])

    return dict(family=family, system_id=sid, X=x, term=term,
                metals=metals, groups=groups,
                chi_M_avg=float(chi), r_ratio=float(rM/_r(x)),
                delta_r=float(dr), deltaQ=float(deltaQ))

# -----------------------------
# Streaming min/max & sets
# -----------------------------
class MinMax:
    def __init__(self):
        self.n = 0
        self.min = float("inf")
        self.max = float("-inf")

    def add(self, x: float):
        self.n += 1
        if x < self.min: self.min = x
        if x > self.max: self.max = x

    def out(self):
        if self.n == 0:
            return {"n": 0, "min": None, "max": None}
        return {"n": self.n, "min": float(self.min), "max": float(self.max)}

class StageAgg:
    def __init__(self):
        self.chi = MinMax()
        self.delta_r = MinMax()
        self.rC = MinMax()
        self.rN = MinMax()
        self.deltaQ = MinMax()
        self.abs_deltaQ = MinMax()
        self.groups: Set[int] = set()
        self.terms: Set[str] = set()
        self.families = Counter()
        self.X = Counter()

    def add(self, feat: Dict[str,Any]):
        self.chi.add(feat["chi_M_avg"])
        self.delta_r.add(feat["delta_r"])
        self.deltaQ.add(feat["deltaQ"])
        self.abs_deltaQ.add(abs(feat["deltaQ"]))
        if feat["X"] == "C": self.rC.add(feat["r_ratio"])
        else: self.rN.add(feat["r_ratio"])
        for g in feat["groups"]:
            self.groups.add(int(g))
        self.terms.add(feat["term"])
        self.families[feat["family"]] += 1
        self.X[feat["X"]] += 1

    def tight_thresholds(self) -> Dict[str,Any]:
        return {
            "groups_present": sorted(self.groups),
            "terms_present": sorted(self.terms),
            "chi_range_minmax": [self.chi.out()["min"], self.chi.out()["max"]],
            "delta_r_max": self.delta_r.out()["max"],
            "r_ratio_bounds_minmax": {
                "C": [self.rC.out()["min"], self.rC.out()["max"]],
                "N": [self.rN.out()["min"], self.rN.out()["max"]],
            },
            "charge_tol_abs_max": self.abs_deltaQ.out()["max"],
        }

    def summary(self) -> Dict[str,Any]:
        return {
            "chi_M_avg": self.chi.out(),
            "delta_r": self.delta_r.out(),
            "deltaQ": self.deltaQ.out(),
            "abs_deltaQ": self.abs_deltaQ.out(),
            "r_ratio_C": self.rC.out(),
            "r_ratio_N": self.rN.out(),
            "groups_present": sorted(self.groups),
            "terms_present": sorted(self.terms),
            "family_counts": dict(self.families),
            "X_counts": dict(self.X),
        }

# -----------------------------
# Pass/fail functions (robust to missing thresholds)
# -----------------------------
def passes_step1(feat: Dict[str,Any], thr: Dict[str,Any]) -> bool:
    s1 = thr.get("step1", {})
    gwh = s1.get("group_whitelist", [])
    chi_range = s1.get("chi_range", [None, None])

    # If step1 thresholds are missing, treat step1 as pass-all (and we will auto-derive)
    if not gwh or chi_range[0] is None or chi_range[1] is None:
        return True

    gset = set(int(x) for x in gwh)
    if any(int(g) not in gset for g in feat["groups"]):
        return False
    return (chi_range[0] <= feat["chi_M_avg"] <= chi_range[1])

def passes_step2(feat: Dict[str,Any], thr: Dict[str,Any]) -> bool:
    allowed = set(thr["step2"]["allowed_terms"])
    return feat["term"] in allowed

def passes_step3(feat: Dict[str,Any], thr: Dict[str,Any]) -> bool:
    return feat["delta_r"] <= float(thr["step3"]["delta_r_max"])

def passes_step4(feat: Dict[str,Any], thr: Dict[str,Any]) -> bool:
    bounds = thr["step4"]["r_ratio_bounds"].get(feat["X"], [None, None])
    if bounds[0] is None or bounds[1] is None:
        return True  # allow pass, will be auto-derived
    lo, hi = float(bounds[0]), float(bounds[1])
    return lo <= feat["r_ratio"] <= hi

def passes_step5(feat: Dict[str,Any], thr: Dict[str,Any]) -> bool:
    return abs(feat["deltaQ"]) <= float(thr["step5"]["charge_tol"])

# -----------------------------
# Auto-derive Step1 & Step4 if missing
# Use survivors of Step2+Step3+Step5 (robust, cheap)
# -----------------------------
def auto_derive_step1_step4(files: List[str], thr: Dict[str,Any], exclude_radioactive: bool) -> Dict[str,Any]:
    agg = StageAgg()
    n_survive = 0

    for fp in files:
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for row in rd:
                feat = compute_features_from_catalog(row)
                if exclude_radioactive and any(is_radioactive(m) for m in feat["metals"]):
                    continue
                # Apply only step2/3/5 as base gate
                if not passes_step2(feat, thr): continue
                if not passes_step3(feat, thr): continue
                if not passes_step5(feat, thr): continue
                n_survive += 1
                agg.add(feat)

    if n_survive == 0:
        raise RuntimeError("Auto-derive failed: no survivors after applying Step2+Step3+Step5. Please loosen those first.")

    # Fill step1
    thr.setdefault("step1", {})
    thr["step1"]["group_whitelist"] = sorted(agg.groups)
    thr["step1"]["chi_range"] = [agg.chi.out()["min"], agg.chi.out()["max"]]

    # Fill step4
    thr.setdefault("step4", {})
    thr["step4"]["r_ratio_bounds"] = {
        "C": [agg.rC.out()["min"], agg.rC.out()["max"]],
        "N": [agg.rN.out()["min"], agg.rN.out()["max"]],
    }

    thr["auto_derived_from"] = {"survivors_step2_3_5": n_survive}
    return thr

# -----------------------------
# Main analyze: stage-by-stage, output exact min/max + tight thresholds
# -----------------------------
def analyze(in_glob: str, thr_json: str, out_json: str, exclude_radioactive: bool):
    files = list_files(in_glob)
    thr = load_thresholds(thr_json)

    # validate minimal presence of step2/3/5
    for k in ["step2","step3","step5"]:
        if k not in thr:
            raise RuntimeError(f"Missing {k} in thresholds file. Provide at least step2/3/5.")
    if "allowed_terms" not in thr["step2"] or not thr["step2"]["allowed_terms"]:
        raise RuntimeError("step2.allowed_terms is empty.")
    if thr["step3"].get("delta_r_max", None) is None:
        raise RuntimeError("step3.delta_r_max is missing.")
    if thr["step5"].get("charge_tol", None) is None:
        raise RuntimeError("step5.charge_tol is missing.")

    # If step1 or step4 incomplete, auto-derive them
    need_step1 = (not thr.get("step1", {}).get("group_whitelist")) or any(v is None for v in thr.get("step1", {}).get("chi_range", [None,None]))
    need_step4 = any(v is None for v in thr.get("step4", {}).get("r_ratio_bounds", {}).get("C", [None,None])) or \
                 any(v is None for v in thr.get("step4", {}).get("r_ratio_bounds", {}).get("N", [None,None]))
    if need_step1 or need_step4:
        thr = auto_derive_step1_step4(files, thr, exclude_radioactive)

    # Stage aggregators
    agg0, agg1, agg2, agg3, agg4, agg5 = StageAgg(), StageAgg(), StageAgg(), StageAgg(), StageAgg(), StageAgg()
    N0=N1=N2=N3=N4=N5=0

    for fp in files:
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for row in rd:
                feat = compute_features_from_catalog(row)
                if exclude_radioactive and any(is_radioactive(m) for m in feat["metals"]):
                    continue

                N0 += 1
                agg0.add(feat)

                if not passes_step1(feat, thr): continue
                N1 += 1
                agg1.add(feat)

                if not passes_step2(feat, thr): continue
                N2 += 1
                agg2.add(feat)

                if not passes_step3(feat, thr): continue
                N3 += 1
                agg3.add(feat)

                if not passes_step4(feat, thr): continue
                N4 += 1
                agg4.add(feat)

                if not passes_step5(feat, thr): continue
                N5 += 1
                agg5.add(feat)

    report = {
        "input_glob": in_glob,
        "exclude_radioactive": exclude_radioactive,
        "thresholds_used_final": thr,
        "counts": {
            "N0_total": N0,
            "N1_after_step1": N1,
            "N2_after_step2": N2,
            "N3_after_step3": N3,
            "N4_after_step4": N4,
            "N5_after_step5": N5
        },
        "stage_summaries_exact_minmax": {
            "N0": agg0.summary(),
            "N1": agg1.summary(),
            "N2": agg2.summary(),
            "N3": agg3.summary(),
            "N4": agg4.summary(),
            "N5": agg5.summary(),
        },
        "tight_thresholds_from_each_stage": {
            "from_N1": agg1.tight_thresholds(),
            "from_N2": agg2.tight_thresholds(),
            "from_N3": agg3.tight_thresholds(),
            "from_N4": agg4.tight_thresholds(),
            "from_N5": agg5.tight_thresholds(),
        }
    }

    report = sanitize_json(report)
    Path(out_json).write_text(json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    print(f"[OK] wrote {out_json}")
    print(json.dumps(report["counts"], indent=2))

def parse_args():
    p = argparse.ArgumentParser(allow_abbrev=False)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze", help="exact min/max + tight thresholds; auto-derive missing step1/step4")
    a.add_argument("--in_glob", required=True)
    a.add_argument("--thr_json", required=True)
    a.add_argument("--out_json", default="reverse_threshold_report.json")
    a.add_argument("--exclude_radioactive", action="store_true")
    return p.parse_args()

def main():
    args = parse_args()
    if args.cmd == "analyze":
        analyze(args.in_glob, args.thr_json, args.out_json, args.exclude_radioactive)

if __name__ == "__main__":
    main()

