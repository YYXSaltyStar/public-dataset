#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse, csv, gzip, glob, json, os
from pathlib import Path
from typing import Dict, Any, List, Set
from collections import Counter
from pymatgen.core.periodic_table import Element

def list_files(in_glob: str) -> List[str]:
    files = sorted(glob.glob(in_glob))
    if not files:
        raise FileNotFoundError(f'No files matched --in_glob="{in_glob}". CWD={os.getcwd()}')
    return files

class MinMax:
    def __init__(self):
        self.n = 0
        self.min = float("inf")
        self.max = float("-inf")
    def add(self, x: float):
        self.n += 1
        if x < self.min: self.min = x
        if x > self.max: self.max = x
    def out(self):
        if self.n == 0:
            return {"n": 0, "min": None, "max": None}
        return {"n": self.n, "min": float(self.min), "max": float(self.max)}

class Agg:
    def __init__(self):
        self.chi = MinMax()
        self.delta_r = MinMax()
        self.rC = MinMax()
        self.rN = MinMax()
        self.deltaQ = MinMax()
        self.abs_deltaQ = MinMax()
        self.groups: Set[int] = set()
        self.terms: Set[str] = set()
        self.X = Counter()
        self.family = Counter()
    def add(self, r: Dict[str,str]):
        self.chi.add(float(r["chi_M_avg"]))
        self.delta_r.add(float(r["delta_r"]))
        dq = float(r["deltaQ"])
        self.deltaQ.add(dq)
        self.abs_deltaQ.add(abs(dq))
        if r["X"] == "C": self.rC.add(float(r["r_ratio"]))
        else: self.rN.add(float(r["r_ratio"]))
        self.terms.add(r["term"])
        self.X[r["X"]] += 1
        self.family[r["family"]] += 1

        # infer groups
        metals = []
        if r["family"] == "HE":
            tag = r["metal_tuple"]
            i = 0
            while i < len(tag):
                if i+2 <= len(tag) and Element.is_valid_symbol(tag[i:i+2]):
                    metals.append(tag[i:i+2]); i += 2
                else:
                    metals.append(tag[i:i+1]); i += 1
        else:
            if r["outer"]: metals.append(r["outer"])
            if r["inner"]: metals.append(r["inner"])
        for m in metals:
            self.groups.add(Element(m).group)

    def tight(self):
        return {
            "chi_range_minmax": [self.chi.out()["min"], self.chi.out()["max"]],
            "delta_r_max": self.delta_r.out()["max"],
            "r_ratio_bounds_minmax": {
                "C": [self.rC.out()["min"], self.rC.out()["max"]],
                "N": [self.rN.out()["min"], self.rN.out()["max"]],
            },
            "charge_tol_abs_max": self.abs_deltaQ.out()["max"],
            "groups_present": sorted(list(self.groups)),
            "terms_present": sorted(list(self.terms)),
            "X_counts": dict(self.X),
            "family_counts": dict(self.family),
        }

def scan(in_glob: str, out_json: str):
    files = list_files(in_glob)
    agg = Agg()
    n = 0
    for fp in files:
        with gzip.open(fp, "rt") as f:
            rd = csv.DictReader(f)
            for r in rd:
                n += 1
                agg.add(r)
    rep = {"rows": n, "tight_thresholds": agg.tight()}
    Path(out_json).write_text(json.dumps(rep, indent=2), encoding="utf-8")
    print(f"[OK] wrote {out_json}")
    print(json.dumps(rep["tight_thresholds"], indent=2))

def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument("--in_glob", required=True,
                    help='e.g. "features/features_shard*.csv.gz" or "mxene_screen_kept_all.csv.gz"')
    ap.add_argument("--out_json", default="tight_thresholds.json")
    args = ap.parse_args()
    scan(args.in_glob, args.out_json)

if __name__ == "__main__":
    main()

